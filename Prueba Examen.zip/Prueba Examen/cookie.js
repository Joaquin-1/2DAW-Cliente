//Crear Cookie

function setCookie(cname, cvalue, exdays) {
    var d = new Date();
    d.setTime(d.getTime() + (exdays * 24 * 60 * 60 * 1000));
    var expires = "expires =" + d.toUTCString();
    document.cookie = cname + "=" + cvalue + ";" + expires + "; path = /";
}

//Obtener valor cookie
function getCookie(cname) {
    let name = cname + "=";
    let ca = document.cookie.split(';');
    for (let i = 0; i < ca.length; i++) {
        let c = ca[i];
        while (c.charAt(0) == ' ') {
            c = c.substring(1);
        }
        if (c.indexOf(name) == 0) {
            return c.substring(name.length, c.length);
        }
    }
    return "";
}

/*
let botonsito = document.getElementById("GuardarDatos");

let usuario = document.getElementById("usuario");
let email = document.getElementById("email");
let dni = document.getElementById("dni");
let rango = ["invitado", "usuario", "administrador"];


botonsito.addEventListener("click", guardarDatos, false);
window.onload = guardarDatos();

function guardarDatos() {

    setCookie("Usuario", usuario.value, 365);
    setCookie("Email", email.value, 365);
    setCookie("Dni", dni.value, 365);
    setCookie("Rango", rango.value, 365);

}

*/


//Modificar cookies
function confirmar() {
    let confirmar = confirm("¿Quieres confirmar los ajustes?");
    if (confirmar) {
        setCookie("inputpomodoro", inputpomodoro.value, 365);
        setCookie("inputsbreak", inputsbreak.value, 365);
        setCookie("inputlbreak", inputlbreak.value, 365);
        setCookie("inputbucles", inputbucles.value, 365);
        alert("Se han guardado los ajustes.");
        salirReload();
    } else {
        alert("No se han producido cambios")
    }
}