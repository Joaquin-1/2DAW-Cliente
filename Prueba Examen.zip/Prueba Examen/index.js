let Blogin = document.getElementById("login");
let bienvenida = document.getElementById("bienvenida");
let fieldset = document.getElementById("fieldset");
Blogin.addEventListener("click", modoUsuario, false);

function modoUsuario() {
    
            let Pdiv = document.getElementById("Pdiv");
            Blogin.remove();

            rango = false;

            
            let boton1 = document.createElement("button");
            let boton2 = document.createElement("button");
            let boton3 = document.createElement("button");
           
            boton1.setAttribute("id", "LogOut");
            boton2.setAttribute("id", "GuardarDatos");
            boton2.setAttribute("disabled", "");
            boton3.setAttribute("id", "ModoAdministrador");

            let c1 = document.createTextNode("LogOut");
            let c2 = document.createTextNode("Guardar Datos");
            let c3 = document.createTextNode("Modo Administrador");

            boton1.appendChild(c1);
            boton2.appendChild(c2);
            boton3.appendChild(c3);

            Pdiv.appendChild(boton1);
            Pdiv.appendChild(boton2);
            Pdiv.appendChild(boton3);

            //------------------------------------------------------------------------

            bienvenida.remove();

            let mensajeError = document.createElement("p");
            mensajeError.setAttribute("id", "mensajeError");
            

            let label1 = document.createElement("label");
            let input1 = document.createElement("input");
            let label2 = document.createElement("label");
            let input2 = document.createElement("input");

            input1.setAttribute("id", "usuario");
            input1.setAttribute("required", "");
            input2.setAttribute("id", "email");
            input2.setAttribute("pattern", "^[a-z]+\d*[a-z]@[a-z]+\.[a-z]{2,3}(\.[a-z]{2,3})?");
            input2.setAttribute("required", "");
            // Modo cerdo input2.setAttribute("type", "email");


            let l1 = document.createTextNode("Usuario: ");
            let l2 = document.createTextNode("Email: ");

            label1.appendChild(l1);
            label2.appendChild(l2);

            fieldset.append(mensajeError ,label1, input1, label2, input2);

            //------------------------------------------------------------------------

            boton1.addEventListener("click", modoInvitado, false);
            boton3.addEventListener("click", modoAdministrador, false);

            input1.addEventListener("blur", validarModoUsuario, false);
            input2.addEventListener("blur", validarModoUsuario, false); 


            let botonsito = document.getElementById("GuardarDatos");
            botonsito.addEventListener("click", guardarCookies, false);
    
}

function modoInvitado() {
    location.reload();


}

function modoAdministrador() {

    let botonAdministrador = document.getElementById("ModoAdministrador")
    rango = true;
    botonAdministrador.remove();
    let guardarDatos = document.getElementById("GuardarDatos")
    guardarDatos.setAttribute("disabled", "");

    let label3 = document.createElement("label");
    let input3 = document.createElement("input");

    input3.setAttribute("id", "dni");
    input3.setAttribute("maxlength", "9");
    input3.setAttribute("pattern", "^[0-9]{8}[A-Z]{1}");
    input3.setAttribute("required", "");

    let l3 = document.createTextNode("DNI: ");
    
    label3.appendChild(l3);
    fieldset.append(label3, input3);

    input3.addEventListener("blur", validarModoAdministrador, false); 
}


//-------------------------------------------------------------------------------------------------

function validaNombre(){
    borrarError();
    var elemento = document.getElementById("usuario");
    if (!elemento.checkValidity()){
        if (elemento.validity.valueMissing){
            error2(elemento, "Debe introducir un nombre de usuario");
        }
        //error(elemento);
        return false;
    }
    return true;
}


function validaEmail(){
    borrarError();
    var elemento = document.getElementById("email");
    if (!elemento.checkValidity()){     
        if (elemento.validity.valueMissing){
            error2(elemento, "Debe introducir un email");
        }
        
        if (elemento.validity.patternMismatch){
            error2(elemento, "Formato de email no válido");
            document.getElementById("email").value = "";
            console.log("Hola")
            //limpiarFormulario();
            
        }
        
        //error(elemento);
        return false;
    }
    return true;
}

function validaDni(){
    borrarError();
    var elemento = document.getElementById("dni");
    if (!elemento.checkValidity()){     
        if (elemento.validity.valueMissing){
            error2(elemento, "Debe introducir un dni");
        }
        
        if (elemento.validity.patternMismatch){
            error2(elemento, "Formato de dni no válido");
            document.getElementById("email").value = "";
            //limpiarFormulario();
            
        }
        
        //error(elemento);
        return false;
    }
    return true;
}



function validarModoUsuario(e) {
    if (validaNombre() && validaEmail()) {
        document.getElementById("mensajeError").innerHTML = "";
        var elemento = document.getElementById("GuardarDatos");
        elemento.removeAttribute('disabled');
        return true;
    } else {
        //Previene que el formulario te lleve a la página "procesar.php"
        e.preventDefault();
        return false;
        
    }
}


function validarModoAdministrador(e) {
    borrarError();
    var elemento = document.getElementById("GuardarDatos");
    if (validaNombre() && validaEmail() && validaDni()) {
        document.getElementById("mensajeError").innerHTML = "";
        elemento.removeAttribute('disabled');
        return true;

    } else {
        //Previene que el formulario te lleve a la página "procesar.php"
        e.preventDefault();
        return false;
    }
}

function error2(elemento, mensaje){
    document.getElementById("mensajeError").innerHTML = mensaje;
    elemento.className="error";
    elemento.focus();
}


function borrarError(){
    var formulario = document.getElementsByTagName("input");
    for (var i = 0; i < formulario.length; i++){
        formulario[i].className="";
    }
}

//--------------------------------------------------------------------------------------------------------------------------------

function setCookie(cname, cvalue, exdays) {
    var d = new Date();
    d.setTime(d.getTime() + (exdays * 24 * 60 * 60 * 1000));
    var expires = "expires =" + d.toUTCString();
    document.cookie = cname + "=" + cvalue + ";" + expires + "; path = /";
}

//Obtener valor cookie
function getCookie(cname) {
    let name = cname + "=";
    let ca = opener.document.cookie.split(';');
    for (let i = 0; i < ca.length; i++) {
        let c = ca[i];
        while (c.charAt(0) == ' ') {
            c = c.substring(1);
        }
        if (c.indexOf(name) == 0) {
            return c.substring(name.length, c.length);
        }
    }
    return "";
}


let rango = false;

function guardarCookies() {
    
    if (rango == true) {
        crearCookiesAdministrador();
    } else {
        crearCookiesUsuario();
    }

}



window.onload = crearCookiesInvitado();

function crearCookiesInvitado() {

    setCookie("Usuario", "", 365);
    setCookie("Email", "", 365);
    setCookie("Dni", "", 365);
    setCookie("Rango", "Invitado", 365);

}


function crearCookiesUsuario() {

    let usuario = document.getElementById("usuario");
    let email = document.getElementById("email");
    
    
    setCookie("Usuario", usuario.value, 365);
    setCookie("Email", email.value, 365);
    setCookie("Rango", "Usuario", 365);


}

function crearCookiesAdministrador() {

    let usuario = document.getElementById("usuario");
    let email = document.getElementById("email");
    let dni = document.getElementById("dni")
    
    setCookie("Usuario", usuario.value, 365);
    setCookie("Email", email.value, 365);
    setCookie("Dni", dni.value, 365);
    setCookie("Rango", "Administrador", 365);


}

